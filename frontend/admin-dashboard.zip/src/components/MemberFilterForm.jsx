import React, { useState } from 'react';
import './MemberFilterForm.css';

export default function MemberFilterForm({ onSearch }) {
  const [filters, setFilters] = useState({
    username: '',
    name: '',
    recommender: '',
    center: '',
    date: '',
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFilters((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSearch(filters);
  };

  return (
    <form className="member-filter-form" onSubmit={handleSubmit}>
      <div className="form-group"><label>아이디</label><input name="username" value={filters.username} onChange={handleChange} /></div>
      <div className="form-group"><label>이름</label><input name="name" value={filters.name} onChange={handleChange} /></div>
      <div className="form-group"><label>추천인</label><input name="recommender" value={filters.recommender} onChange={handleChange} /></div>
      <div className="form-group"><label>센터</label><input name="center" value={filters.center} onChange={handleChange} /></div>
      <div className="form-group"><label>날짜</label><input name="date" type="date" value={filters.date} onChange={handleChange} /></div>
      <div className="form-actions"><button type="submit">검색</button></div>
    </form>
  );
}
