import React from 'react';
import './MemberTable.css';

export default function MemberTable({ data }) {
  return (
    <div className="member-table-wrapper">
      <table className="member-table">
        <thead>
          <tr>
            <th>등록일</th>
            <th>아이디</th>
            <th>이름</th>
            <th>센터</th>
            <th>추천인</th>
          </tr>
        </thead>
        <tbody>
          {data.map((member) => (
            <tr key={member.id}>
              <td>{member.created_at}</td>
              <td>{member.username}</td>
              <td>{member.name}</td>
              <td>{member.center}</td>
              <td>{member.recommender}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
