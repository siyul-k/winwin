import React, { useState, useEffect } from 'react';
import Header from '../components/Header';
import SummaryCards from '../components/SummaryCards';
import MemberFilterForm from '../components/MemberFilterForm';
import MemberTable from '../components/MemberTable';

export default function AdminDashboardPage() {
  const [members, setMembers] = useState([]);
  const [loading, setLoading] = useState(true);

  const fetchMembers = async (filters = {}) => {
    setLoading(true);
    try {
      const res = await fetch('/api/admin/members');
      const data = await res.json();
      setMembers(data);
    } catch (err) {
      console.error('회원 목록 조회 에러:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchMembers();
  }, []);

  return (
    <div>
      <Header />
      <SummaryCards />
      <MemberFilterForm onSearch={fetchMembers} />
      {loading ? <p>로딩 중...</p> : <MemberTable data={members} />}
    </div>
  );
}
